package com.photoreal.terrain.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3541;
import net.minecraft.class_5820;
import net.minecraft.class_6910;
import net.minecraft.class_7243;

public class SmoothDensityFunction implements class_6910 {

    public static final MapCodec<SmoothDensityFunction> CODEC = RecordCodecBuilder.mapCodec(instance ->
        instance.group(
            Codec.LONG.fieldOf("seed").orElse(0L).forGetter(f -> f.seed),
            Codec.DOUBLE.fieldOf("terrain_scale").orElse(80.0).forGetter(f -> f.terrainScale),
            Codec.DOUBLE.fieldOf("horizontal_scale").orElse(256.0).forGetter(f -> f.horizontalScale),
            Codec.INT.fieldOf("sea_level").orElse(64).forGetter(f -> f.seaLevel),
            Codec.INT.fieldOf("octaves").orElse(6).forGetter(f -> f.octaves),
            Codec.DOUBLE.fieldOf("cave_strength").orElse(0.35).forGetter(f -> f.caveStrength)
        ).apply(instance, SmoothDensityFunction::new)
    );

    private final long seed;
    private final double terrainScale;
    private final double horizontalScale;
    private final int seaLevel;
    private final int octaves;
    private final double caveStrength;

    private final class_3541 terrainNoise;
    private final class_3541 detailNoise;
    private final class_3541 caveNoise;
    private final class_3541 warpNoiseX;
    private final class_3541 warpNoiseZ;

    private static final double PERSISTENCE   = 0.5;
    private static final double LACUNARITY    = 1.987;
    private static final double WARP_STRENGTH = 48.0;

    public SmoothDensityFunction(long seed, double terrainScale, double horizontalScale,
                                 int seaLevel, int octaves, double caveStrength) {
        this.seed           = seed;
        this.terrainScale   = terrainScale;
        this.horizontalScale = horizontalScale;
        this.seaLevel       = seaLevel;
        this.octaves        = octaves;
        this.caveStrength   = caveStrength;

        this.terrainNoise = new class_3541(new class_5820(seed));
        this.detailNoise  = new class_3541(new class_5820(seed + 1337L));
        this.caveNoise    = new class_3541(new class_5820(seed + 7331L));
        this.warpNoiseX   = new class_3541(new class_5820(seed + 9999L));
        this.warpNoiseZ   = new class_3541(new class_5820(seed + 1111L));
    }

    @Override
    public double method_40464(class_6910.class_6912 pos) {
        double x = pos.comp_371();
        double y = pos.comp_372();
        double z = pos.comp_373();

        double warpX = sampleSimplex(warpNoiseX, x * 0.004, y * 0.002, z * 0.004) * WARP_STRENGTH;
        double warpZ = sampleSimplex(warpNoiseZ, x * 0.004, y * 0.002, z * 0.004) * WARP_STRENGTH;

        double wx = x + warpX;
        double wz = z + warpZ;

        double terrain = fbm(wx, y * 0.5, wz, octaves, terrainNoise);
        double detail = fbm(wx * 2.0, y, wz * 2.0, 3, detailNoise) * 0.25;
        double yBias = computeYBias(y);

        double density = yBias + terrain + detail;

        if (caveStrength > 0.0 && y < seaLevel + 16) {
            double caveFactor = sampleCave(wx, y, wz);
            double caveDepthWeight = smoothstep(
                clamp((seaLevel + 16 - y) / 32.0, 0.0, 1.0)
            );
            density -= caveFactor * caveStrength * caveDepthWeight;
        }

        return clamp(density, comp_377(), comp_378());
    }

    private double computeYBias(double y) {
        double normalizedY = (seaLevel - y) / terrainScale;
        return sigmoid(normalizedY * 1.8) * 1.2;
    }

    private double sigmoid(double x) {
        return (2.0 / (1.0 + Math.exp(-x))) - 1.0;
    }

    private double fbm(double x, double y, double z, int numOctaves, class_3541 sampler) {
        double amplitude     = 1.0;
        double frequency     = 1.0 / horizontalScale;
        double value         = 0.0;
        double maxAmplitude  = 0.0;

        for (int i = 0; i < numOctaves; i++) {
            value        += amplitude * sampleSimplex(sampler, x * frequency, y * frequency, z * frequency);
            maxAmplitude += amplitude;
            amplitude    *= PERSISTENCE;
            frequency    *= LACUNARITY;
        }

        return value / maxAmplitude;
    }

    private double sampleCave(double x, double y, double z) {
        double n1 = sampleSimplex(caveNoise, x * 0.008, y * 0.012, z * 0.008);
        double n2 = sampleSimplex(caveNoise, x * 0.008 + 100, y * 0.012 + 100, z * 0.008 + 100);

        double dist = Math.sqrt(n1 * n1 + n2 * n2);
        double threshold = 0.18;
        if (dist < threshold) {
            return smoothstep(1.0 - (dist / threshold));
        }
        return 0.0;
    }

    private static double sampleSimplex(class_3541 sampler, double x, double y, double z) {
        return sampler.method_22416(x, y, z);
    }

    private static double smoothstep(double t) {
        t = clamp(t, 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public double comp_377() {
        return -2.0;
    }

    @Override
    public double comp_378() {
        return 2.0;
    }

    // ИСПРАВЛЕНИЕ: Вот это то самое двойное название из Fabric Yarn
    @Override
    public class_6910 method_40469(class_6910.class_6915 visitor) {
        return visitor.apply(this);
    }

    @Override
    public class_7243<? extends class_6910> method_41062() {
        return class_7243.method_42116(CODEC);
    }

    @Override
    public void method_40470(double[] densities, class_6910.class_6911 applier) {
        applier.method_40478(densities, this);
    }
}