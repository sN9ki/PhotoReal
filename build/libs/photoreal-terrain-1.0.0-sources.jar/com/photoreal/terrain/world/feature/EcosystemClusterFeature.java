package com.photoreal.terrain.world.feature;

import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_5281;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_7924;

/**
 * ============================================================
 *  EcosystemClusterFeature — органический кластер экосистемы
 * ============================================================
 *
 * КОНЦЕПЦИЯ:
 * ----------
 * Вместо равномерного случайного размещения деревьев (vanilla подход)
 * этот Feature генерирует ЕДИНЫЙ СВЯЗНЫЙ КЛАСТЕР:
 *
 *   Центр (r < 3):          Массивное дерево (Dark Oak / Jungle)
 *   Средний пояс (3 < r < 8): 3-5 деревьев среднего размера
 *   Внешний пояс (8 < r < 14): Подлесок, кусты, папоротники
 *   Случайно:               Моховые булыжники, упавшие бревна
 *
 * АЛГОРИТМ РАЗМЕЩЕНИЯ: Poisson Disk Sampling
 * -------------------------------------------
 * Стандартный Random даёт равномерное распределение → деревья
 * выглядят «рассыпанными». Poisson Disk гарантирует минимальное
 * расстояние между точками → органическое «стояние» деревьев.
 *
 * Алгоритм Бриджсона (упрощённая версия):
 *   1. Начинаем с центральной точки
 *   2. Для каждой активной точки пробуем k=30 новых точек
 *      на расстоянии [r, 2r] от неё
 *   3. Если точка не конфликтует с существующими → добавляем
 *   4. Иначе → точка становится неактивной
 *
 * СЕМЕНА (seed) ДЛЯ ДЕТЕРМИНИЗМА:
 * --------------------------------
 * Используем BlockPos.asLong() как seed → один и тот же кластер
 * при перезагрузке мира. Никаких аллокаций UUID.
 */
public class EcosystemClusterFeature extends class_3031<EcosystemClusterConfig> {

    // Ключи PlacedFeature для элементов кластера
    // (регистрируются в PhotorealFeatures, используются через RegistryEntryLookup)
    private static final class_2960 CANOPY_TREE_ID =
        new class_2960("photoreal_terrain", "photoreal_canopy_tree");
    private static final class_2960 MEDIUM_TREE_ID =
        new class_2960("photoreal_terrain", "photoreal_medium_tree");
    private static final class_2960 BUSH_ID =
        new class_2960("photoreal_terrain", "photoreal_bush");
    private static final class_2960 UNDERGROWTH_ID =
        new class_2960("photoreal_terrain", "photoreal_undergrowth_patch");
    private static final class_2960 BOULDER_ID =
        new class_2960("photoreal_terrain", "photoreal_mossy_boulder");

    public EcosystemClusterFeature(Codec<EcosystemClusterConfig> configCodec) {
        super(configCodec);
    }

    @Override
    public boolean method_13151(class_5821<EcosystemClusterConfig> ctx) {
        EcosystemClusterConfig config = ctx.method_33656();
        class_5281 world    = ctx.method_33652();
        class_2338 origin               = ctx.method_33655();
        class_5819 random                 = ctx.method_33654();

        // Находим поверхность в центральной точке
        class_2338 surfaceCenter = getSurface(world, origin);
        if (surfaceCenter == null) return false;

        int placed = 0;

        // ── Шаг 1: Центральное дерево (массивный дуб/тёмный дуб) ─────────────
        placed += placeFeatureAt(world, random, surfaceCenter, CANOPY_TREE_ID, ctx) ? 1 : 0;

        // ── Шаг 2: Poisson Disk Sampling для деревьев среднего яруса ─────────
        List<class_2338> treePositions = poissonDiskSample(
            surfaceCenter, config.radius() - 2, config.minTreeSpacing(), random, 12
        );

        for (class_2338 treePos : treePositions) {
            float r = (float) Math.sqrt(
                Math.pow(treePos.method_10263() - surfaceCenter.method_10263(), 2) +
                Math.pow(treePos.method_10260() - surfaceCenter.method_10260(), 2)
            );

            class_2338 surface = getSurface(world, treePos);
            if (surface == null) continue;

            if (r < 4f) {
                // Ближняя зона → средние деревья
                placed += placeFeatureAt(world, random, surface, MEDIUM_TREE_ID, ctx) ? 1 : 0;
            } else if (r < 9f) {
                // Средняя зона → малые деревья или кусты
                class_2960 id = random.method_43057() < 0.6f ? MEDIUM_TREE_ID : BUSH_ID;
                placed += placeFeatureAt(world, random, surface, id, ctx) ? 1 : 0;
            } else {
                // Внешняя зона → только кусты и подлесок
                placed += placeFeatureAt(world, random, surface, BUSH_ID, ctx) ? 1 : 0;
            }
        }

        // ── Шаг 3: Активный подлесок (случайные попытки в радиусе) ──────────
        for (int i = 0; i < config.undergrowthAttempts(); i++) {
            double angle = random.method_43058() * 2 * Math.PI;
            double dist  = random.method_43058() * config.radius();
            int dx = (int)(Math.cos(angle) * dist);
            int dz = (int)(Math.sin(angle) * dist);
            class_2338 pos = getSurface(world, origin.method_10069(dx, 0, dz));
            if (pos != null) {
                placeFeatureAt(world, random, pos, UNDERGROWTH_ID, ctx);
            }
        }

        // ── Шаг 4: Моховые булыжники (bulders) ───────────────────────────────
        if (random.method_43057() < config.boulderChance()) {
            int boulderCount = 1 + random.method_43048(3);
            for (int i = 0; i < boulderCount; i++) {
                placeMossyBoulder(world, random, surfaceCenter, config.radius());
            }
        }

        // ── Шаг 5: Упавшие брёвна ────────────────────────────────────────────
        if (random.method_43057() < config.fallenLogChance()) {
            placeFallenLog(world, random, surfaceCenter, config.radius());
        }

        return placed > 0;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  POISSON DISK SAMPLING
    //  Генерирует органично распределённые точки без слипания
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Упрощённый алгоритм Бриджсона для 2D Poisson Disk Sampling.
     *
     * @param center     центральная точка
     * @param radius     радиус области размещения
     * @param minDist    минимальное расстояние между точками
     * @param random     RNG
     * @param maxPoints  максимальное количество точек
     * @return список BlockPos (Y не задан, использовать getSurface())
     */
    private List<class_2338> poissonDiskSample(class_2338 center, int radius,
                                              float minDist, class_5819 random,
                                              int maxPoints) {
        List<class_2338> points  = new ArrayList<>();
        List<class_2338> active  = new ArrayList<>();

        // Первая точка: среднее расстояние от центра (не в самом центре — там canopy tree)
        class_2338 first = center.method_10069(
            (int)(Math.cos(random.method_43058() * Math.PI * 2) * (minDist + 2)),
            0,
            (int)(Math.sin(random.method_43058() * Math.PI * 2) * (minDist + 2))
        );
        points.add(first);
        active.add(first);

        int k = 20; // попыток на активную точку

        while (!active.isEmpty() && points.size() < maxPoints) {
            int idx = random.method_43048(active.size());
            class_2338 current = active.get(idx);
            boolean placed = false;

            for (int attempt = 0; attempt < k; attempt++) {
                // Случайная точка на кольце [minDist, 2*minDist] от current
                double angle = random.method_43058() * 2 * Math.PI;
                double dist  = minDist + random.method_43058() * minDist;
                int nx = current.method_10263() + (int)(Math.cos(angle) * dist);
                int nz = current.method_10260() + (int)(Math.sin(angle) * dist);

                // Проверка: в пределах радиуса
                double dr = Math.sqrt(
                    Math.pow(nx - center.method_10263(), 2) + Math.pow(nz - center.method_10260(), 2)
                );
                if (dr > radius) continue;

                class_2338 candidate = new class_2338(nx, center.method_10264(), nz);

                // Проверка: не слишком близко к другим точкам
                boolean tooClose = false;
                for (class_2338 existing : points) {
                    double d2 = Math.sqrt(
                        Math.pow(existing.method_10263() - nx, 2) + Math.pow(existing.method_10260() - nz, 2)
                    );
                    if (d2 < minDist) { tooClose = true; break; }
                }

                if (!tooClose) {
                    points.add(candidate);
                    active.add(candidate);
                    placed = true;
                    break;
                }
            }

            if (!placed) {
                active.remove(idx); // Исчерпана — удаляем из активных
            }
        }

        return points;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PLACE HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Находит верхний блок воздуха над твёрдой поверхностью. */
    private class_2338 getSurface(class_5281 world, class_2338 base) {
        class_2338.class_2339 mutable = new class_2338.class_2339(base.method_10263(), base.method_10264(), base.method_10260());

        // Ищем твёрдую поверхность сверху вниз в диапазоне ±16 блоков
        for (int dy = 16; dy > -16; dy--) {
            mutable.method_33098(base.method_10264() + dy);
            if (world.method_8320(mutable).method_26212(world, mutable)) {
                return mutable.method_10084().method_10062();
            }
        }
        return null;
    }

    /**
     * Размещает PlacedFeature по ID из реестра.
     * Использует мировой RegistryEntry lookup (нет аллокаций RegistryKey).
     */
    private boolean placeFeatureAt(class_5281 world, class_5819 random,
                                    class_2338 pos, class_2960 featureId, class_5821<EcosystemClusterConfig> ctx) {
        var lookup = world.method_30349().method_33310(class_7924.field_41245);
        if (lookup.isEmpty()) return false;

        var entry = lookup.get().method_40264(class_5321.method_29179(class_7924.field_41245, featureId));
        if (entry.isEmpty()) return false;

        return entry.get().comp_349().method_39644(world, ctx.method_33653(), random, pos);
    }

    /** Размещает моховый булыжник (2-3 блока) на случайной позиции. */
    private void placeMossyBoulder(class_5281 world, class_5819 random,
                                    class_2338 center, int radius) {
        double angle = random.method_43058() * 2 * Math.PI;
        double dist  = 3 + random.method_43058() * (radius - 4);
        int bx = center.method_10263() + (int)(Math.cos(angle) * dist);
        int bz = center.method_10260() + (int)(Math.sin(angle) * dist);
        class_2338 surface = getSurface(world, new class_2338(bx, center.method_10264(), bz));
        if (surface == null) return;

        // Основной блок + 1-2 соседних для вида кучки
        world.method_8652(surface, class_2246.field_9989.method_9564(), 2);
        if (random.method_43056()) {
            world.method_8652(surface.method_10078(), class_2246.field_9989.method_9564(), 2);
        }
        if (random.method_43056()) {
            world.method_8652(surface.method_10084(), class_2246.field_9989.method_9564(), 2);
        }
        if (random.method_43056()) {
            world.method_8652(surface.method_10095(), class_2246.field_10065.method_9564(), 2);
        }
    }

    /** Размещает упавшее бревно (горизонтальное) на случайной позиции. */
    private void placeFallenLog(class_5281 world, class_5819 random,
                                 class_2338 center, int radius) {
        double angle  = random.method_43058() * 2 * Math.PI;
        double dist   = 4 + random.method_43058() * (radius - 5);
        int bx = center.method_10263() + (int)(Math.cos(angle) * dist);
        int bz = center.method_10260() + (int)(Math.sin(angle) * dist);
        class_2338 surface = getSurface(world, new class_2338(bx, center.method_10264(), bz));
        if (surface == null) return;

        // Горизонтальное бревно длиной 3-4 блока
        // Ориентация: случайная (X или Z)
        class_2350.class_2351 axis = random.method_43056() ? class_2350.class_2351.field_11048 : class_2350.class_2351.field_11051;
        class_2680 log = class_2246.field_10431.method_9564()
            .method_11657(class_2465.field_11459, axis);

        int logLength = 3 + random.method_43048(2);
        for (int i = 0; i < logLength; i++) {
            class_2338 logPos = axis == class_2350.class_2351.field_11048
                ? surface.method_10069(i, 0, 0)
                : surface.method_10069(0, 0, i);
            if (world.method_8320(logPos).method_26215()) {
                world.method_8652(logPos, log, 2);
            }
            // Мох на бревне
            if (random.method_43057() < 0.4f) {
                class_2338 moss = logPos.method_10084();
                if (world.method_8320(moss).method_26215()) {
                    world.method_8652(moss, class_2246.field_28680.method_9564(), 2);
                }
            }
        }
    }
}
