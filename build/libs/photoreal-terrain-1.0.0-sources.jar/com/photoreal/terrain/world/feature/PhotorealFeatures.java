package com.photoreal.terrain.world.feature;

import com.photoreal.terrain.PhotorealTerrainMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_7923;

/**
 * Регистрация всех кастомных Feature мода.
 * Вызывается из PhotorealTerrainMod.onInitialize().
 */
public final class PhotorealFeatures {

    public static final class_3031<EcosystemClusterConfig> ECOSYSTEM_CLUSTER =
        new EcosystemClusterFeature(EcosystemClusterConfig.CODEC);

    public static void register() {
        class_2378.method_10230(
            class_7923.field_41144,
            new class_2960(PhotorealTerrainMod.MOD_ID, "ecosystem_cluster"),
            ECOSYSTEM_CLUSTER
        );
        PhotorealTerrainMod.LOGGER.info("[PhotorealTerrain] Features зарегистрированы.");
    }

    private PhotorealFeatures() {}
}
