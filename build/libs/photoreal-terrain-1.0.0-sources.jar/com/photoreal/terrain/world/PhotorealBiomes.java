package com.photoreal.terrain.world;

import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Реестровые ключи для всех кастомных биомов мода.
 * Фактическое содержимое биома — в JSON-файле датапака.
 */
public final class PhotorealBiomes {

    public static final class_5321<net.minecraft.class_1959> PHOTOREAL_DENSE_FOREST =
        class_5321.method_29179(class_7924.field_41236,
            new class_2960("photoreal_terrain", "photoreal_dense_forest"));

    private PhotorealBiomes() {}
}
