package com.photoreal.terrain.flora;

import com.photoreal.terrain.PhotorealTerrainMod;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import java.util.HashMap;
import java.util.Map;

public class FloraModelProvider implements ModelLoadingPlugin {

    private static final Map<class_2248, FloraCustomModel.FloraType> FLORA_TYPES = new HashMap<>();

    static {
        // Растения (крест-формы)
        FLORA_TYPES.put(class_2246.field_10479,          FloraCustomModel.FloraType.CROSS_PLANT);
        FLORA_TYPES.put(class_2246.field_10214,     FloraCustomModel.FloraType.CROSS_PLANT);
        FLORA_TYPES.put(class_2246.field_10112,           FloraCustomModel.FloraType.CROSS_PLANT);
        FLORA_TYPES.put(class_2246.field_10182,      FloraCustomModel.FloraType.CROSS_PLANT);
        FLORA_TYPES.put(class_2246.field_10449,          FloraCustomModel.FloraType.CROSS_PLANT);
        FLORA_TYPES.put(class_2246.field_10086,    FloraCustomModel.FloraType.CROSS_PLANT);

        // Брёвна — процедурный октагональный цилиндр
        FLORA_TYPES.put(class_2246.field_10431,        FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_10511,      FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_10037,     FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_10306,     FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_10533,     FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_10010,   FloraCustomModel.FloraType.LOG_CYLINDER);
        FLORA_TYPES.put(class_2246.field_37545,   FloraCustomModel.FloraType.LOG_CYLINDER);

        // Листья — кластер случайных квадов
        FLORA_TYPES.put(class_2246.field_10503,     FloraCustomModel.FloraType.LEAF_CLUSTER);
        FLORA_TYPES.put(class_2246.field_10539,   FloraCustomModel.FloraType.LEAF_CLUSTER);
        FLORA_TYPES.put(class_2246.field_9988,  FloraCustomModel.FloraType.LEAF_CLUSTER);
        FLORA_TYPES.put(class_2246.field_10335,  FloraCustomModel.FloraType.LEAF_CLUSTER);
        FLORA_TYPES.put(class_2246.field_10098,  FloraCustomModel.FloraType.LEAF_CLUSTER);
    }

    public static boolean isFloraBlock(class_2248 block) {
        return FLORA_TYPES.containsKey(block);
    }

    public static FloraCustomModel.FloraType getType(class_2248 block) {
        return FLORA_TYPES.get(block);
    }

    @Override
    public void onInitializeModelLoader(Context pluginContext) {
        // ИСПРАВЛЕНИЕ: Использование явного анонимного класса вместо лямбды
        pluginContext.modifyModelAfterBake().register(new ModelModifier.AfterBake() {
            @Override
            public class_1087 modifyModelAfterBake(class_1087 model, net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier.AfterBake.Context context) {
                class_2960 id = context.id();
                class_2248 block = findBlockByModelId(id);
                
                if (block == null || !isFloraBlock(block)) {
                    return model; 
                }

                FloraCustomModel.FloraType type = getType(block);
                class_1058 primary = model.method_4711();
                class_1058 secondary = extractSecondarySprite(block);

                return new FloraCustomModel(type, primary, secondary, primary);
            }
        });
    }

    private static class_2248 findBlockByModelId(class_2960 modelId) {
        String path = modelId.method_12832();
        if (!path.startsWith("block/")) return null;

        String blockName = path.substring("block/".length());
        for (Map.Entry<class_2248, FloraCustomModel.FloraType> entry : FLORA_TYPES.entrySet()) {
            class_2248 block = entry.getKey();
            String registryName = net.minecraft.class_7923.field_41175.method_10221(block).method_12832();
            if (blockName.equals(registryName) || blockName.startsWith(registryName + "_")) {
                return block;
            }
        }
        return null;
    }

    private static class_1058 extractSecondarySprite(class_2248 block) {
        if (FLORA_TYPES.get(block) != FloraCustomModel.FloraType.LOG_CYLINDER) return null;

        String registryName = net.minecraft.class_7923.field_41175.method_10221(block).method_12832();
        class_4730 capId = new class_4730(
            class_1059.field_5275,
            new class_2960("minecraft", "block/" + registryName + "_top")
        );

        try {
            return capId.method_24148();
        } catch (Exception e) {
            return null;
        }
    }
}