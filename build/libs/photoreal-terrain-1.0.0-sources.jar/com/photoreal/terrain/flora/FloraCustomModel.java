package com.photoreal.terrain.flora;

import com.photoreal.terrain.worldgen.ChunkDensityCache;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public class FloraCustomModel implements class_1087, FabricBakedModel {

    public enum FloraType {
        CROSS_PLANT,
        LOG_CYLINDER,
        LEAF_CLUSTER
    }

    private final FloraType type;
    private final class_1058 primarySprite;
    private final class_1058 secondarySprite;
    private final class_1058 particleSprite;

    public FloraCustomModel(FloraType type, class_1058 primarySprite,
                             class_1058 secondarySprite, class_1058 particleSprite) {
        this.type = type;
        this.primarySprite  = primarySprite;
        this.secondarySprite = secondarySprite;
        this.particleSprite = particleSprite;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView,
                                class_2680 state,
                                class_2338 pos,
                                Supplier<class_5819> randomSupplier,
                                RenderContext context) {

        ChunkDensityCache cache = ChunkDensityCache.get();

        float wx = pos.method_10263();
        float wy = pos.method_10264();
        float wz = pos.method_10260();

        int tint = -1;
        if (type == FloraType.CROSS_PLANT || type == FloraType.LEAF_CLUSTER) {
            tint = blockView.method_23752(pos, (biome, bx, bz) -> biome.method_8698());
        }

        QuadEmitter emitter = context.getEmitter();

        switch (type) {
            case CROSS_PLANT -> TerrainAlignedCross.emit(emitter, primarySprite, cache, wx, wy, wz, tint, true);
            case LOG_CYLINDER -> ProceduralCylinder.emit(emitter, primarySprite, secondarySprite != null ? secondarySprite : primarySprite, cache, wx, wy, wz, 0.5f, 0.5f, true);
            case LEAF_CLUSTER -> {
                long seed = pos.method_10063();
                TerrainAlignedCross.emitLeafCluster(emitter, primarySprite, tint, 0.5f, 0.5f, 0.5f, seed, 8, 0.4f);
            }
        }
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
    }

    @Override
    public List<class_777> method_4707(class_2680 state, class_2350 face, class_5819 random) {
        return Collections.emptyList();
    }

    @Override
    public boolean method_4708() {
        return type != FloraType.CROSS_PLANT;
    }

    // ИСПРАВЛЕНИЕ: В 1.20.1 метод называется hasDepth()
    @Override
    public boolean method_4712() {
        return true;
    }

    @Override
    public boolean method_4713() {
        return false;
    }

    // ИСПРАВЛЕНИЕ: Обязательный метод для 1.20.1
    @Override
    public boolean method_24304() {
        return true;
    }

    @Override
    public class_1058 method_4711() {
        return particleSprite;
    }

    @Override
    public class_809 method_4709() {
        return class_809.field_4301;
    }

    @Override
    public class_806 method_4710() {
        return class_806.field_4292;
    }
}